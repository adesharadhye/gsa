from rest_framework import serializers
from .models import Login, Register, Task
from django.contrib.auth import get_user_model


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = "__all__"


class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Register
        fields = "__all__"

class LoginSerializer(serializers.ModelSerializer):
    class Meta:
        model = Login
        fields = "__all__"

class TaskSerializer(serializers.ModelSerializer):
    # assigned_to = UserSerializer(read_only=True)
    # assigned_to_id = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), source='assigned_to', write_only=True)
    class Meta:
        model = Task
        fields = "__all__"