
from rest_framework import generics, status
from django.contrib.auth import authenticate, login
from rest_framework.views import APIView
from rest_framework import viewsets 
from django.contrib.auth.models import User
from rest_framework.response import Response
from .serializers import TaskSerializer, RegisterSerializer , UserSerializer, LoginSerializer
from .models import Task, Login ,Register
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth import get_user_model

class UserViewSet(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = UserSerializer
    queryset = get_user_model().objects.all()


class RegisterViewSet(viewsets.ModelViewSet):
    queryset = Register.objects.all()
    serializer_class = RegisterSerializer

class LoginViewSet(viewsets.ModelViewSet):
    queryset = Login.objects.all()
    serializer_class = LoginSerializer
    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')
        user = authenticate(request, email=email, password=password)
        if user is not None:
            login(request, user)
            return Response({'message': 'Login successful'}, status=status.HTTP_200_OK)
        return Response({'error': 'Invalid Credentials'}, status=status.HTTP_400_BAD_REQUEST)

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    

