from django.db import models

class Register(models.Model):
    name=models.CharField(max_length=80)
    email = models.EmailField(unique=True)
    password=models.CharField(max_length=50)
    mobile_number = models.CharField(max_length=15)
    address = models.CharField(max_length=255)

    # latitude = models.FloatField(null=True, blank=True)
    # longitude = models.FloatField(null=True, blank=True)

    def __str__(self):
        return self.email

class Login(models.Model):
    email=models.EmailField(max_length=70)
    password=models.CharField(max_length=80)


class Task(models.Model):
    name_task=models.CharField(max_length=80)
    date=models.DateField()
    time=models.TimeField()
    assigned_by=models.CharField(max_length=80)
    status=models.CharField(max_length=40, choices=(("pending", "Pending"),("completed","Completed")))

